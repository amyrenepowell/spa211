Symple Shortcodes WordPress Plugin
=================

A free shortcodes plugin for WordPress

Don't forget to check out the parameters on the wiki page:

https://github.com/wpexplorer/symple-shortcodes/wiki/Shortcode-Parameters
